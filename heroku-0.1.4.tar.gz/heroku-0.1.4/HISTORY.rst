History
-------
0.1.4 (2013-05-30)
++++++++++++++++++

* Ignore what it's netrc
* Fix Process.new() so it can spawn one-off processes
* 'ps' keyword support for app logs

0.1.3 (2013-05-01)
++++++++++++++++++

* Support for Labs (https://devcenter.heroku.com/articles/labs)
* Bugfixes.
* Better error handling.

0.1.2 (2012-02-25)
++++++++++++++++++

* Bugfixes.
* dateutil requirement.

0.1.0 (2011-12-21)
++++++++++++++++++

* Initial release.

